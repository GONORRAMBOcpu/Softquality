"""
API de SoftQuality — avance de los 3 casos de uso a cargo de Sebastián:
  1. Subir Proyecto      -> POST /proyectos
  2. Solicitar Revisión  -> POST /proyectos/{proyecto_id}/versiones/{version_id}/solicitar-revision
  3. Dashboard           -> GET  /proyectos  y  GET /proyectos/{proyecto_id}/dashboard

Para correrlo:
    cd backend
    python -m venv venv && source venv/bin/activate   (en Windows: venv\\Scripts\\activate)
    pip install -r requirements.txt
    uvicorn app.main:app --reload

Luego abre http://127.0.0.1:8000/docs para probar la API directamente
(FastAPI genera esa documentación interactiva solo, sección 5 del Prompt Maestro).
"""

from pathlib import Path

from fastapi import FastAPI, Depends, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session

from . import models, schemas
from .database import engine, get_db
from .motor_analisis import calcular_metricas_iso25010, generar_recomendacion_ia

models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="SoftQuality API - Avance")

# Se deja el CORS abierto por si alguien prueba la API desde otra herramienta,
# aunque ya no es indispensable: la página HTML la sirve este mismo servidor.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

RUTA_STATIC = Path(__file__).parent / "static"


@app.get("/")
def raiz():
    """Sirve la página (un solo archivo HTML, sin necesidad de Node/npm)."""
    return FileResponse(RUTA_STATIC / "index.html")


# ---------- 1. Subir Proyecto ----------

@app.post("/proyectos", response_model=schemas.ProyectoSalida)
def subir_proyecto(datos: schemas.ProyectoCrear, db: Session = Depends(get_db)):
    """Registra un proyecto nuevo y le crea automáticamente su primera versión."""
    proyecto = models.Proyecto(
        nombre=datos.nombre,
        descripcion=datos.descripcion,
        repositorio_url=datos.repositorio_url,
    )
    db.add(proyecto)
    db.commit()
    db.refresh(proyecto)

    primera_version = models.Version(
        proyecto_id=proyecto.id, etiqueta=datos.etiqueta_version
    )
    db.add(primera_version)
    db.commit()
    db.refresh(proyecto)

    return proyecto


@app.get("/proyectos", response_model=list[schemas.ProyectoSalida])
def listar_proyectos(db: Session = Depends(get_db)):
    return db.query(models.Proyecto).all()


# ---------- 2. Solicitar Revisión (incluye Verificar Proyecto por la IA) ----------

@app.post(
    "/proyectos/{proyecto_id}/versiones/{version_id}/solicitar-revision",
    response_model=schemas.VersionSalida,
)
def solicitar_revision(proyecto_id: int, version_id: int, db: Session = Depends(get_db)):
    """
    Ejecuta el análisis (métricas vs ISO/IEC 25010) y luego pide al
    Motor de IA que interprete esas métricas y genere una recomendación.
    """
    version = (
        db.query(models.Version)
        .filter(models.Version.id == version_id, models.Version.proyecto_id == proyecto_id)
        .first()
    )
    if not version:
        raise HTTPException(status_code=404, detail="Versión no encontrada")

    proyecto = db.query(models.Proyecto).filter(models.Proyecto.id == proyecto_id).first()

    metricas = calcular_metricas_iso25010()
    recomendacion = generar_recomendacion_ia(proyecto.nombre, metricas)

    resultado_existente = (
        db.query(models.Resultado).filter(models.Resultado.version_id == version_id).first()
    )
    if resultado_existente:
        resultado_existente.metricas_iso25010 = metricas
        resultado_existente.recomendacion_ia = recomendacion
    else:
        resultado_existente = models.Resultado(
            version_id=version_id,
            metricas_iso25010=metricas,
            recomendacion_ia=recomendacion,
        )
        db.add(resultado_existente)

    db.commit()
    db.refresh(version)
    return version


# Nota: el caso de uso "Dashboard" se deja para una siguiente entrega;
# este avance cubre solo Subir Proyecto y Solicitar Revisión.
