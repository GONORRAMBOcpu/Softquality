"""
Modelos de base de datos.

Siguiendo el Prompt Maestro (sección 9, glosario):
- Proyecto: unidad registrada por el usuario.
- Version: snapshot de un proyecto, usada para comparar evolución.
- Resultado: métricas (mapeadas a ISO/IEC 25010) + recomendación de la IA
  para una versión concreta, generado al "Solicitar Revisión".
"""

from sqlalchemy import Column, Integer, String, Text, DateTime, ForeignKey, JSON
from sqlalchemy.orm import relationship
from datetime import datetime

from .database import Base


class Proyecto(Base):
    __tablename__ = "proyectos"

    id = Column(Integer, primary_key=True, index=True)
    nombre = Column(String, nullable=False)
    descripcion = Column(Text, default="")
    repositorio_url = Column(String, default="")
    creado_en = Column(DateTime, default=datetime.utcnow)

    versiones = relationship(
        "Version", back_populates="proyecto", cascade="all, delete-orphan"
    )


class Version(Base):
    __tablename__ = "versiones"

    id = Column(Integer, primary_key=True, index=True)
    proyecto_id = Column(Integer, ForeignKey("proyectos.id"), nullable=False)
    etiqueta = Column(String, nullable=False)  # ej. "v1.0", "Sprint 2"
    creado_en = Column(DateTime, default=datetime.utcnow)

    proyecto = relationship("Proyecto", back_populates="versiones")
    resultado = relationship(
        "Resultado", back_populates="version", uselist=False,
        cascade="all, delete-orphan"
    )


class Resultado(Base):
    """
    Se crea cuando el usuario "Solicita Revisión" para una versión.
    - metricas_iso25010: valores calculados por el motor de análisis,
      agrupados por característica ISO/IEC 25010 (JSON).
    - recomendacion_ia: texto generado por el Motor de IA a partir de
      esas métricas (la IA interpreta, no calcula — regla 3 del Prompt Maestro).
    """

    __tablename__ = "resultados"

    id = Column(Integer, primary_key=True, index=True)
    version_id = Column(Integer, ForeignKey("versiones.id"), nullable=False, unique=True)
    metricas_iso25010 = Column(JSON, nullable=False)
    recomendacion_ia = Column(Text, nullable=False)
    creado_en = Column(DateTime, default=datetime.utcnow)

    version = relationship("Version", back_populates="resultado")
