"""
Conexión a la base de datos.

Para este AVANCE usamos SQLite (un solo archivo, no requiere instalar nada).
Cuando el equipo tenga listo el docker-compose con PostgreSQL (definido en el
Prompt Maestro, sección 5), solo hay que cambiar SQLALCHEMY_DATABASE_URL por
la cadena de conexión de Postgres. El resto del código (modelos, endpoints)
no cambia, porque SQLAlchemy abstrae el motor de base de datos.
"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base

SQLALCHEMY_DATABASE_URL = "sqlite:///./softquality.db"

engine = create_engine(
    SQLALCHEMY_DATABASE_URL, connect_args={"check_same_thread": False}
)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()


def get_db():
    """Abre una sesión de base de datos para un request y la cierra al terminar."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
