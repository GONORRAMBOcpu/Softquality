"""
Estos dos módulos están separados a propósito (regla 2 del Prompt Maestro:
CRUD, motor de análisis e interpretación por IA son módulos independientes).

Para el AVANCE, el cálculo de métricas y la respuesta de la IA están
simulados con datos de ejemplo, para poder mostrar el flujo completo
(Subir Proyecto -> Solicitar Revisión -> Dashboard) sin depender todavía
de herramientas externas de análisis ni de una API key de Gemini.

Cuando el equipo conecte el analizador real y Gemini 2.5 Pro, solo hay que
reemplazar el contenido de estas dos funciones; el resto de la aplicación
(endpoints, base de datos, frontend) no necesita cambiar.
"""

import random


def calcular_metricas_iso25010() -> dict:
    """
    Simula el análisis de un proyecto y devuelve un puntaje (0-100)
    por cada característica de ISO/IEC 25010.
    En la versión final, aquí se integrarían herramientas reales
    (linters, cobertura de pruebas, análisis de seguridad, etc.).
    """
    caracteristicas = [
        "Funcionalidad",
        "Fiabilidad",
        "Usabilidad",
        "Eficiencia",
        "Mantenibilidad",
        "Portabilidad",
        "Seguridad",
        "Compatibilidad",
    ]
    return {c: round(random.uniform(55, 95), 1) for c in caracteristicas}


def generar_recomendacion_ia(nombre_proyecto: str, metricas: dict) -> str:
    """
    Simula al Motor de IA interpretando métricas ya calculadas
    (nunca calcula métricas, solo genera texto de recomendación —
    regla 3 del Prompt Maestro).
    """
    peor_caracteristica = min(metricas, key=metricas.get)
    mejor_caracteristica = max(metricas, key=metricas.get)

    return (
        f"Análisis de '{nombre_proyecto}': el punto más fuerte es "
        f"{mejor_caracteristica} ({metricas[mejor_caracteristica]}/100). "
        f"El área que más necesita atención es {peor_caracteristica} "
        f"({metricas[peor_caracteristica]}/100); se recomienda revisar "
        f"esa característica antes de la siguiente entrega. "
        f"Recuerda: este diagnóstico es una guía de mejora continua y no "
        f"constituye una certificación oficial ISO/IEC 25010 ni CMMI."
    )
