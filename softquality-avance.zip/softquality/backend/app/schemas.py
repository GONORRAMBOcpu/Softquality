from pydantic import BaseModel
from datetime import datetime
from typing import Optional


class ProyectoCrear(BaseModel):
    nombre: str
    descripcion: Optional[str] = ""
    repositorio_url: Optional[str] = ""
    etiqueta_version: Optional[str] = "v1.0"


class ResultadoSalida(BaseModel):
    id: int
    metricas_iso25010: dict
    recomendacion_ia: str
    creado_en: datetime

    class Config:
        from_attributes = True


class VersionSalida(BaseModel):
    id: int
    etiqueta: str
    creado_en: datetime
    resultado: Optional[ResultadoSalida] = None

    class Config:
        from_attributes = True


class ProyectoSalida(BaseModel):
    id: int
    nombre: str
    descripcion: str
    repositorio_url: str
    creado_en: datetime
    versiones: list[VersionSalida] = []

    class Config:
        from_attributes = True
