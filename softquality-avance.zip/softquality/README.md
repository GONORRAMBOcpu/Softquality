# SoftQuality — Avance (Subir Proyecto y Solicitar Revisión)

Este es un avance funcional de la parte del proyecto a cargo de Sebastián:
**Subir Proyecto** y **Solicitar Revisión**. Sigue el stack definido en el
Prompt Maestro (Python + FastAPI). Para que sea lo más fácil posible de
correr, la página web va incluida dentro del propio backend — no hace falta
instalar Node.js ni npm, ni abrir dos terminales.

Para simplificar el avance, la base de datos es SQLite en vez de
PostgreSQL, y el "motor de IA" está simulado (no llama todavía a Gemini) —
ambas cosas están señaladas en el código con comentarios de dónde se
conectarían las piezas reales.

## Qué incluye

1. **Subir Proyecto** — formulario que registra un proyecto y crea su versión v1.0.
2. **Solicitar Revisión** — ejecuta el "análisis" (simulado) contra las 8
   características de ISO/IEC 25010 y pide al "motor de IA" (simulado) una
   recomendación en texto.

El caso de uso **Dashboard** se deja para una siguiente entrega.

## Cómo correrlo (una sola terminal)

Necesitas tener Python instalado. Luego:

```bash
cd backend
python -m venv venv
source venv/bin/activate        # en Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload
```

Cuando veas el mensaje `Uvicorn running on http://127.0.0.1:8000`, abre esa
misma dirección en el navegador: **http://127.0.0.1:8000**

Ahí verás la página con las dos pestañas, ya lista para usar. También puedes
abrir `http://127.0.0.1:8000/docs` para ver la API sola (esa página la
genera FastAPI automáticamente).

## Orden para probarlo

1. En la pestaña **Subir proyecto**, registra un proyecto.
2. Cambia a **Solicitar revisión**, elige ese proyecto y su versión v1.0, y
   pide la revisión. Verás las métricas y la recomendación generada.

## Qué falta para la versión final (según el Prompt Maestro)

- Cambiar SQLite por PostgreSQL (Docker + docker-compose).
- Conectar el motor de análisis real (herramientas de métricas de código).
- Conectar la API de Gemini 2.5 Pro (o un modelo local con Ollama) en vez del
  texto simulado.
- Agregar registro/login con JWT y roles Usuario/Administrador.
- Agregar el checklist de madurez CMMI.
- Construir el caso de uso Dashboard.
